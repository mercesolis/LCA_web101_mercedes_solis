export default { guid: Date.now() };
