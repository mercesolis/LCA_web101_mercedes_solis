export default ( /HTML$/i );
